// fake TS source
