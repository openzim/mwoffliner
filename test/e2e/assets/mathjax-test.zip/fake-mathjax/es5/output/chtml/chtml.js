/* fake MathJax 3 chtml output */
