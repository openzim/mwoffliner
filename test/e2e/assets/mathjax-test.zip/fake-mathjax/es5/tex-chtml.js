/* fake MathJax 3 tex-chtml entry point */
