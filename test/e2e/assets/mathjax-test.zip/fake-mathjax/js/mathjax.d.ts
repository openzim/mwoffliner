// fake declaration
